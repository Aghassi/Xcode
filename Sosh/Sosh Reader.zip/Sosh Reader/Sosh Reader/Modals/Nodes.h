//
//  Nodes.h
//  Sosh Reader
//
//  Created by David Aghassi on 1/13/14.
//  Copyright (c) 2014 Aghassi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Nodes : NSObject

@property (nonatomic, weak) NSString *line;
@property (nonatomic) NSUInteger length;

@end
